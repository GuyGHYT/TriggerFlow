# Here is where you can make your own functions available as TriggerFlow plugins.
# Example:

def functionExample(param1, param2):
    return print(f"Function Example called with {param1} and {param2}")

# Note:
# You do need to know some Python to create useful commands here.
# If you don't know, I recommend AI to write a function for you.
# VSCode/GitHub Copilot in Agent mode is phenomenal for this.
# Happy Coding! - GuyGHYT