import triggerflowlib as tfl

root = tfl.ui.CreateButtonLayout()
root.mainloop()
